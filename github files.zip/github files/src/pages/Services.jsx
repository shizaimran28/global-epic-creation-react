// src/pages/Services.jsx - Premium Dark Theme (Fixed)
import React, { useEffect, useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { Link } from "react-router-dom";
import heroDesktop from "../assets/hero.jpg";
import heroMobile from "../assets/hero2.jpg";
import cta from "../assets/CTA.jpg";
import SocialMediaPackages from "../components/packages/SocialMediaPackages";
import WebsitePackages from "../components/packages/WebsitePackages";
import {
  Code,
  Palette,
  Megaphone,
  Share2,
  PenTool,
  BookOpen,
  TrendingUp,
  Search,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Rocket,
  Target,
  Zap,
  Shield,
  BarChart3,
  Smartphone,
  Clock,
} from "lucide-react";

// ============================================
// ALL COMPONENTS DEFINED FIRST (before Services)
// ============================================

// Hero Section
const HeroSection = () => {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 60]);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[70vh] flex items-center justify-center overflow-hidden"
    >
      <div
        className="absolute inset-0 z-0 w-full h-full hidden sm:block"
        style={{
          backgroundImage: `url(${heroDesktop})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />
      <div
        className="absolute inset-0 z-0 w-full h-full block sm:hidden"
        style={{
          backgroundImage: `url(${heroMobile})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90 z-0" />
      <motion.div
        className="container-custom relative z-10 text-center"
        style={{ y }}
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4 pt-16 leading-[1.2] tracking-tight">
            Our{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Services
            </span>
          </h1>
          <p className="text-gray-400 text-sm sm:text-base max-w-2xl mx-auto">
            From strategy to execution, we provide end-to-end services that
            deliver measurable results.
          </p>
        </motion.div>
      </motion.div>
    </section>
  );
};

// Service Card Component
const ServiceCard = ({ service, index, isInView }) => {
  const isEven = index % 2 === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="grid lg:grid-cols-2 gap-12 items-center"
    >
      <div className={isEven ? "order-1" : "order-1 lg:order-2"}>
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 mb-6">
          <service.icon size={32} className="text-cyan-400" />
        </div>
        <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
          {service.title}
        </h2>
        <p className="text-gray-400 text-lg mb-6 leading-relaxed">
          {service.description}
        </p>
        <div className="grid grid-cols-2 gap-3 mb-8">
          {service.features.map((feature, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <CheckCircle size={16} className="text-cyan-400" />
              <span className="text-gray-300 text-sm">{feature}</span>
            </div>
          ))}
        </div>
        <Link
          to="/contact"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:gap-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:shadow-lg hover:shadow-cyan-500/30"
        >
          Get Consultation <ArrowRight size={14} />
        </Link>
      </div>

      <div className={isEven ? "order-2" : "order-2 lg:order-1"}>
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-2xl blur opacity-30 group-hover:opacity-60 transition duration-500" />
          <div className="relative rounded-2xl overflow-hidden">
            <img
              src={service.image}
              alt={service.title}
              className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// Services Grid Section
const ServicesGridSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const services = [
    {
      icon: Code,
      title: "Web Development",
      description:
        "Custom websites and web applications built with modern technologies for optimal performance and scalability.",
      features: [
        "Responsive Design",
        "E-commerce Solutions",
        "CMS Integration",
        "Performance Optimization",
      ],
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
    },
    {
      icon: Palette,
      title: "UI/UX Designing",
      description:
        "User-centered design solutions that create intuitive, engaging, and memorable digital experiences.",
      features: [
        "Wireframing",
        "Prototyping",
        "User Research",
        "Interaction Design",
      ],
      image:
        "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=600&h=400&fit=crop",
    },
    {
      icon: Megaphone,
      title: "Digital Marketing",
      description:
        "Data-driven marketing strategies that increase brand awareness and drive measurable results.",
      features: [
        "Social Media Marketing",
        "Email Campaigns",
        "Content Strategy",
        "Analytics & Reporting",
      ],
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
    },
    {
      icon: Share2,
      title: "Social Media Handling",
      description:
        "Comprehensive social media management that builds community and drives engagement.",
      features: [
        "Content Creation",
        "Community Management",
        "Paid Advertising",
        "Performance Tracking",
      ],
      image:
        "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=600&h=400&fit=crop",
    },
    {
      icon: PenTool,
      title: "Graphic Designing",
      description:
        "Visual storytelling through stunning designs that capture attention and communicate effectively.",
      features: [
        "Brand Identity",
        "Print Design",
        "Digital Assets",
        "Motion Graphics",
      ],
      image:
        "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=400&fit=crop",
    },
    {
      icon: BookOpen,
      title: "E-book Publishing",
      description:
        "Professional e-book creation and publishing services for authors and businesses.",
      features: [
        "Content Development",
        "Cover Design",
        "Formatting",
        "Distribution Strategy",
      ],
      image:
        "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&h=400&fit=crop",
    },
    {
      icon: TrendingUp,
      title: "Branding Solutions",
      description:
        "Comprehensive branding that creates a unique identity and emotional connection with your audience.",
      features: [
        "Brand Strategy",
        "Visual Identity",
        "Brand Guidelines",
        "Brand Voice",
      ],
      image:
        "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600&h=400&fit=crop",
    },
    {
      icon: Search,
      title: "SEO Optimization",
      description:
        "Strategic SEO solutions that improve visibility and drive organic traffic.",
      features: [
        "Keyword Research",
        "On-Page SEO",
        "Technical SEO",
        "Link Building",
      ],
      image:
        "https://images.unsplash.com/photo-1562577309-4932fdd64cd1?w=600&h=400&fit=crop",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black/40">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-cyan-400 text-sm font-semibold uppercase tracking-wider mb-4 block">
            Our Expertise
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Services That
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {" "}
              Deliver Results
            </span>
          </h2>
          <p className="text-gray-400">
            Comprehensive digital solutions tailored to your business needs.
          </p>
        </motion.div>

        <div className="space-y-32">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              service={service}
              index={index}
              isInView={isInView}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// Process Section
const ProcessSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const steps = [
    {
      icon: Target,
      title: "Discovery",
      description: "Understanding your goals and market landscape.",
    },
    {
      icon: Rocket,
      title: "Strategy",
      description: "Developing a comprehensive roadmap for success.",
    },
    {
      icon: Zap,
      title: "Execution",
      description: "Bringing ideas to life with precision.",
    },
    {
      icon: TrendingUp,
      title: "Optimization",
      description: "Continuous improvement for growth.",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black/60">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-cyan-400 text-sm font-semibold uppercase tracking-wider mb-4 block">
            Our Process
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            How We
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {" "}
              Bring Ideas to Life
            </span>
          </h2>
          <p className="text-gray-400">
            A streamlined approach that ensures quality and efficiency.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-500/30 transition-all duration-300 group"
            >
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <step.icon size={24} className="text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {step.title}
              </h3>
              <p className="text-gray-500 text-sm">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Why Choose Us Section
const WhyChooseUsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const benefits = [
    {
      icon: Shield,
      title: "Expert Team",
      desc: "Years of industry experience",
    },
    { icon: BarChart3, title: "Data-Driven", desc: "Results-focused approach" },
    {
      icon: Smartphone,
      title: "Mobile First",
      desc: "Optimized for all devices",
    },
    { icon: Zap, title: "Fast Delivery", desc: "Quick turnaround times" },
  ];

  return (
    <section ref={ref} className="py-24 bg-black/40">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-cyan-400 text-sm font-semibold uppercase tracking-wider mb-4 block">
              Why Choose Us
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
              The
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                {" "}
                EPIC Advantage
              </span>
            </h2>
            <p className="text-gray-400 mb-6">
              We combine cutting-edge technology with creative excellence to
              deliver exceptional results for our clients.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {benefits.map((benefit, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10"
                >
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <benefit.icon size={16} className="text-cyan-400" />
                  </div>
                  <div>
                    <h4 className="text-white font-semibold text-sm">
                      {benefit.title}
                    </h4>
                    <p className="text-gray-500 text-xs">{benefit.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              {[
                { value: "98%", label: "Client Satisfaction" },
                { value: "3x", label: "Avg ROI" },
                { value: "0", label: "Missed Deadlines" },
                { value: "24/7", label: "Support Available" },
              ].map((stat, i) => (
                <div
                  key={i}
                  className="text-center p-6 rounded-2xl bg-white/5 border border-white/10"
                >
                  <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                    {stat.value}
                  </div>
                  <div className="text-gray-500 text-sm mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// CTA Section
const CTASection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="py-24 relative">
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          backgroundImage: `url(${cta})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="absolute inset-0 bg-black/70" />
      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Ready to Elevate
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {" "}
              Your Business?
            </span>
          </h2>
          <p className="text-gray-300 mb-8">
            Let's discuss how our services can help you achieve your goals.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/30"
            style={{ background: "linear-gradient(135deg, #0AB3C7, #006C92)" }}
          >
            Get Free Consultation <ArrowRight size={14} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

// ============================================
// MAIN SERVICES COMPONENT (at the bottom)
// ============================================
const Services = () => {
  useEffect(() => {
    document.body.classList.add("bg-black");
    return () => document.body.classList.remove("bg-black");
  }, []);

  return (
    <div className="bg-black overflow-x-hidden">
      <HeroSection />
      <ServicesGridSection />
      <ProcessSection />
      <WhyChooseUsSection />
      <SocialMediaPackages />
      <WebsitePackages />
      <CTASection />
    </div>
  );
};

export default Services;
