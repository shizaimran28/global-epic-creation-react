import React, { useRef, useState, useEffect } from "react";
import {
  motion,
  useInView,
  useScroll,
  useTransform,
  AnimatePresence,
} from "framer-motion";
import { Link } from "react-router-dom";
import heroDesktop from "../assets/hero.jpg";
import heroMobile from "../assets/hero2.jpg";
import cta from "../assets/CTA.jpg";
import TrustedSection from "../components/TrustedMarquee";
import SocialMediaPackages from "../components/packages/SocialMediaPackages";
import WebsitePackages from "../components/packages/WebsitePackages";
import {
  ArrowRight,
  Code2,
  Palette,
  Megaphone,
  Share2,
  PenTool,
  Search,
  Star,
  Play,
  Zap,
  Target,
  Globe,
  Users,
  Award,
  Briefcase,
  Shield,
  Clock,
  ChevronRight,
  Quote,
  ExternalLink,
  TrendingUp,
  Calendar,
  CalendarDays,
  BarChart3,
  FileCode,
  Layout,
  Lock,
  MousePointer,
  RefreshCw,
  Database,
  Package as PackageIcon,
  CreditCard,
  Store,
  FileText,
  ShoppingCart,
} from "lucide-react";

// ─── Faster Animation Variants ────────────────────────────────────────────────
const fadeUpFast = {
  hidden: { opacity: 0, y: 30 },
  visible: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.08, ease: "easeOut" },
  }),
};

const fadeLeftFast = {
  hidden: { opacity: 0, x: -40 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const fadeRightFast = {
  hidden: { opacity: 0, x: 40 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const scaleFast = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.4, ease: "easeOut" },
  },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.2 },
  },
};

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

// ─── Section Label Component ───────────────────────────────────────────────────
const SectionLabel = ({ children }) => (
  <motion.div
    variants={fadeUpFast}
    className="inline-flex items-center gap-2 mb-6"
  >
    <span className="w-2 h-2 rounded-full bg-cyan-400" />
    <span className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">
      {children}
    </span>
  </motion.div>
);

// ─── Section Header Component ──────────────────────────────────────────────────
const SectionHeader = ({ label, title, subtitle, centered = true }) => (
  <div className={`${centered ? "text-center" : "text-left"} mb-16`}>
    <div className={`flex ${centered ? "justify-center" : "justify-start"}`}>
      <SectionLabel>{label}</SectionLabel>
    </div>
    <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-[1.2] tracking-tight">
      {title}
    </h2>
    {subtitle && (
      <p className="text-gray-400 text-base max-w-2xl mx-auto leading-relaxed">
        {subtitle}
      </p>
    )}
  </div>
);

// ─── Hero Section with Typewriter Animation (Fixed) ───────────────────────────────
const HeroSection = () => {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 60]);

  // Typewriter animation states
  const [displayText, setDisplayText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const words = ["ATTENTION", "TRAFFIC", "LEADS", "SALES", "GROWTH"];
  const typingSpeed = 100;
  const deletingSpeed = 50;
  const pauseDuration = 1500;

  useEffect(() => {
    let timeout;

    if (isPaused) {
      timeout = setTimeout(() => {
        setIsPaused(false);
        setIsDeleting(true);
      }, pauseDuration);
      return () => clearTimeout(timeout);
    }

    const currentWord = words[currentIndex];

    if (!isDeleting && displayText === currentWord) {
      setIsPaused(true);
      return;
    }

    if (isDeleting && displayText === "") {
      setIsDeleting(false);
      setCurrentIndex((prev) => (prev + 1) % words.length);
      return;
    }

    timeout = setTimeout(
      () => {
        if (!isDeleting) {
          setDisplayText(currentWord.slice(0, displayText.length + 1));
        } else {
          setDisplayText(currentWord.slice(0, displayText.length - 1));
        }
      },
      isDeleting ? deletingSpeed : typingSpeed,
    );

    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, currentIndex, isPaused, words]);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[100vh] flex items-center justify-center overflow-hidden"
    >
      {/* Desktop Background */}
      <div
        className="absolute inset-0 z-0 w-full h-full hidden sm:block"
        style={{
          backgroundImage: `url(${heroDesktop})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* Mobile Background */}
      <div
        className="absolute inset-0 z-0 w-full h-full block sm:hidden"
        style={{
          backgroundImage: `url(${heroMobile})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* BLACK OVERLAY */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90 z-0" />

      {/* Content */}
      <motion.div
        className="container-custom relative z-10 w-full text-center"
        style={{ y }}
      >
        <div className="max-w-5xl mx-auto px-4 pt-28">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-8 leading-[1.2]"
          >
            TURN{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {displayText}
            </span>
            <span className="inline-block w-0.5 h-8 md:h-10 lg:h-12 bg-gradient-to-t from-cyan-400 to-blue-500 ml-1 animate-pulse" />{" "}
            INTO <br />
            REVENUE
          </motion.h1>

          {/* Company Intro */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-gray-300 text-sm md:text-base max-w-2xl mx-auto mb-8 leading-relaxed"
          >
            EPIC CREATION is a full-service digital agency helping businesses
            grow through innovative web development, strategic marketing, and
            creative design solutions.
          </motion.p>

          {/* Minimal Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-wrap items-center justify-center gap-4"
          >
            <Link
              to="/contact"
              className="px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/30"
              style={{
                background: "linear-gradient(135deg, #0AB3C7, #006C92)",
              }}
            >
              Get Started
            </Link>

            <Link
              to="/portfolio"
              className="px-6 py-3 rounded-md font-semibold text-cyan-400 text-sm transition-all duration-300 hover:scale-105 hover:text-white hover:bg-cyan-500/20"
              style={{
                border: "1px solid rgba(10,179,199,0.4)",
                background: "transparent",
              }}
            >
              View Our Work
            </Link>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};
// ─── About Section ──────────────────────────────────────────────────────────────
const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const metrics = [
    { value: "200+", label: "Projects", icon: Briefcase },
    { value: "150+", label: "Clients", icon: Users },
    { value: "15+", label: "Countries", icon: Globe },
    { value: "98%", label: "Retention", icon: Award },
  ];

  return (
    <section ref={ref} className="py-20 bg-black/40">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=450&fit=crop"
                alt="Team"
                className="w-full h-auto object-cover"
              />
            </div>
            <motion.div
              className="absolute -bottom-4 -right-4 rounded-xl p-4 bg-white/5 backdrop-blur border border-white/10"
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                8+
              </div>
              <div className="text-xs text-gray-400">Years</div>
            </motion.div>
          </motion.div>

          {/* Right Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5 }}
          >
            <SectionLabel>About Us</SectionLabel>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              We Turn Ideas Into{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Digital Reality
              </span>
            </h2>
            <p className="text-gray-400 leading-relaxed mb-4">
              Founded with a passion for innovation, EPIC CREATION has grown
              into a full-service digital agency serving clients worldwide.
            </p>
            <p className="text-gray-400 leading-relaxed mb-6">
              We build lasting partnerships with our clients, navigating the
              digital landscape together.
            </p>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              {metrics.map((metric, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <metric.icon size={16} className="text-cyan-400" />
                  </div>
                  <div>
                    <div className="text-lg font-bold text-white">
                      {metric.value}
                    </div>
                    <div className="text-xs text-gray-500">{metric.label}</div>
                  </div>
                </div>
              ))}
            </div>

            <Link
              to="/about"
              className="inline-flex items-center gap-2 text-cyan-400 font-semibold text-sm hover:gap-3 transition-all"
            >
              Learn More <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// ─── Services Section - Premium Vertical Timeline with Icons ─────────────────────
const ServicesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const services = [
    {
      id: "01",
      icon: Code2,
      title: "Web Development",
      description:
        "Our web development services create powerful online presences that convert visitors into customers. From simple brochure sites to complex web applications, we build solutions tailored to your business needs.",
    },
    {
      id: "02",
      icon: PenTool,
      title: "Graphic Designing",
      description:
        "Visual identity systems that tell your brand story. From logos to complete brand guidelines, we create memorable experiences that resonate with your audience and build lasting brand recognition.",
    },
    {
      id: "03",
      icon: Megaphone,
      title: "Digital Marketing",
      description:
        "Data-driven marketing strategies that maximize ROI. We turn clicks into customers with precision targeting, analytics-backed decisions, and comprehensive campaign management across all digital channels.",
    },
    {
      id: "04",
      icon: Share2,
      title: "Social Media Marketing",
      description:
        "Amplify your brand's reach with our strategic social media marketing. We create engaging content, run targeted campaigns, and analyze performance to maximize your ROI across all major platforms.",
    },
    {
      id: "05",
      icon: Palette,
      title: "UI/UX Designing",
      description:
        "Intuitive interfaces that users love. We combine psychology with design to create seamless digital experiences that drive engagement, satisfaction, and long-term user loyalty.",
    },
    {
      id: "06",
      icon: Search,
      title: "E-book Publishing",
      description:
        "Professional e-book creation from concept to global distribution. Transform your expertise into authority with beautifully designed digital publications that establish thought leadership.",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black">
      <div className="container-custom mx-auto px-4 md:px-6 max-w-5xl">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <span className="text-xs font-mono text-cyan-400 mb-2 block tracking-wider">
            WHAT WE DO
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Our Comprehensive{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Services
            </span>
          </h2>
          <p className="text-gray-400 text-sm max-w-2xl mx-auto">
            End-to-end solutions to power your business growth in the digital
            age
          </p>
        </motion.div>

        {/* Services Timeline - Icons on left side */}
        <div className="space-y-8 md:space-y-10">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex flex-col md:flex-row gap-5 md:gap-6 lg:gap-8 group"
            >
              {/* Left side - Icon Container */}
              <div className="md:w-18 lg:w-20 flex-shrink-0">
                <motion.div
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  className="w-10 h-10 md:w-12 md:h-12 rounded-md bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 flex items-center justify-center transition-all duration-300 group-hover:border-cyan-500/40 group-hover:shadow-lg group-hover:shadow-cyan-500/10"
                >
                  <service.icon
                    size={24}
                    className="text-cyan-400 transition-all duration-300 group-hover:scale-110"
                    strokeWidth={1.5}
                  />
                </motion.div>
              </div>

              {/* Right side - Content */}
              <div className="flex-1">
                <h3 className="text-xl md:text-2xl font-bold text-white mb-2 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-cyan-400 transition-all duration-300">
                  {service.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center mt-12 pt-6"
        >
          <Link
            to="/services"
            className="inline-flex items-center gap-2 text-cyan-400 font-semibold text-sm hover:gap-3 transition-all duration-300 group"
          >
            <span>View all services</span>
            <ArrowRight
              size={14}
              className="group-hover:translate-x-1 transition-transform duration-300"
            />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

// ─── Accelerate Business Growth Section - 3 Column Grid ─────────────────────────
const GrowthSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const features = [
    {
      icon: Zap,
      title: "Boost Sales",
      description:
        "Increase revenue with our powerful POS systems that streamline transactions and enhance customer experience",
      points: [
        "Faster checkout process",
        "Multiple payment options",
        "Real-time sales tracking",
      ],
    },
    {
      icon: Globe,
      title: "Expand Online",
      description:
        "Establish your digital presence with professional websites that convert visitors into customers",
      points: [
        "Mobile-responsive design",
        "SEO optimized",
        "E-commerce capabilities",
      ],
    },
    {
      icon: Users,
      title: "Engage Customers",
      description:
        "Build lasting relationships through targeted marketing and exceptional service experiences",
      points: [
        "Customer loyalty programs",
        "Social media integration",
        "Personalized promotions",
      ],
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black">
      <div className="container-custom mx-auto px-4 md:px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Accelerate Your Business Growth
          </h2>
          <p className="text-gray-400 text-base max-w-2xl mx-auto">
            Comprehensive solutions designed to help your business thrive in the
            digital age
          </p>
        </motion.div>

        {/* 3 Column Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group"
            >
              <div className="p-6 rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                {/* Icon */}
                <div className="mb-5">
                  <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center group-hover:bg-cyan-500/20 transition-all duration-300">
                    <feature.icon size={22} className="text-cyan-400" />
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-cyan-400 transition-colors duration-300">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {feature.description}
                </p>

                {/* Bullet Points */}
                <ul className="space-y-2 mb-6">
                  {feature.points.map((point, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-cyan-400" />
                      <span className="text-gray-500 text-sm">{point}</span>
                    </li>
                  ))}
                </ul>

                {/* Learn More Link */}
                <Link
                  to="/services"
                  className="inline-flex items-center gap-2 text-cyan-400 text-sm font-medium hover:gap-3 transition-all duration-300 group/link"
                >
                  <span>Learn More</span>
                  <ArrowRight
                    size={14}
                    className="group-hover/link:translate-x-1 transition-transform duration-300"
                  />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ─── Why Choose Us Section ──────────────────────────────────────────────────────
const WhyChooseUsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const features = [
    {
      icon: Zap,
      title: "Fast Delivery",
      desc: "Agile methodology and efficient workflows.",
    },
    {
      icon: Shield,
      title: "Security",
      desc: "Military-grade security standards.",
    },
    {
      icon: Target,
      title: "Results-Driven",
      desc: "Data-backed decisions for maximum ROI.",
    },
    {
      icon: Clock,
      title: "24/7 Support",
      desc: "Round-the-clock technical support.",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-black/30">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5 }}
          >
            <SectionLabel>Why Choose Us</SectionLabel>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              The{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                EPIC Advantage
              </span>
            </h2>
            <p className="text-gray-400 mb-6">
              We combine cutting-edge technology with creative excellence.
            </p>

            <div className="space-y-4">
              {features.map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.3, delay: i * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <feature.icon size={16} className="text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">
                      {feature.title}
                    </h3>
                    <p className="text-gray-500 text-xs">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="p-6 rounded-xl bg-white/5 border border-white/10">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { value: "98%", label: "Satisfaction" },
                  { value: "3x", label: "Avg ROI" },
                  { value: "0", label: "Missed Deadlines" },
                  { value: "24/7", label: "Support" },
                ].map((stat, i) => (
                  <div
                    key={i}
                    className="text-center p-3 rounded-lg bg-black/50"
                  >
                    <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                      {stat.value}
                    </div>
                    <div className="text-xs text-gray-400">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// ─── Portfolio Preview Section ──────────────────────────────────────────────────
const PortfolioPreviewSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const projects = [
    {
      title: "Luxury E-Commerce",
      category: "Web Dev",
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&h=400&fit=crop",
    },
    {
      title: "FinTech App",
      category: "UI/UX",
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=500&h=400&fit=crop",
    },
    {
      title: "Brand Identity",
      category: "Branding",
      image:
        "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=500&h=400&fit=crop",
    },
  ];

  return (
    <section ref={ref} className="py-20 bg-black/40">
      <div className="container-custom">
        <div className="flex justify-between items-center mb-10">
          <div>
            <SectionLabel>Our Work</SectionLabel>
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Featured{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Projects
              </span>
            </h2>
          </div>
          <Link
            to="/portfolio"
            className="text-cyan-400 text-sm font-semibold hover:underline"
          >
            View All →
          </Link>
        </div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-3 gap-5"
        >
          {projects.map((project, i) => (
            <motion.div
              key={i}
              variants={staggerItem}
              className="group cursor-pointer overflow-hidden rounded-xl"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-56 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <div>
                    <p className="text-cyan-400 text-xs">{project.category}</p>
                    <h3 className="text-white font-bold">{project.title}</h3>
                  </div>
                </div>
              </div>
              <div className="mt-3">
                <p className="text-cyan-400 text-xs">{project.category}</p>
                <h3 className="text-white font-semibold text-sm">
                  {project.title}
                </h3>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// ─── Testimonials Section ───────────────────────────────────────────────────────
const testimonials = [
  {
    quote:
      "EPIC CREATION transformed our digital presence. The ROI has been phenomenal.",
    name: "Sarah Mitchell",
    role: "CEO, NexGen Ventures",
    avatar: "SM",
  },
  {
    quote:
      "Increased our conversion rate by 40% in the first month. Outstanding work!",
    name: "James Carter",
    role: "Founder, Luxe Fashion",
    avatar: "JC",
  },
  {
    quote: "Professional, creative, and results-driven. Highly recommended!",
    name: "Priya Sharma",
    role: "CMO, Helix Software",
    avatar: "PS",
  },
];

const TestimonialsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((c) => (c + 1) % testimonials.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section ref={ref} className="py-20 bg-black/60">
      <div className="container-custom">
        <SectionHeader
          label="Testimonials"
          title="What Our Clients Say"
          subtitle="Hear from the brands we've helped succeed."
        />

        <div className="max-w-3xl mx-auto">
          <AnimatePresence>
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="p-8 rounded-xl bg-white/5 border border-white/10 text-center"
            >
              <Quote className="w-10 h-10 text-cyan-500/30 mx-auto mb-4" />
              <p className="text-white text-lg leading-relaxed mb-6">
                "{testimonials[current].quote}"
              </p>
              <div>
                <div className="font-bold text-white">
                  {testimonials[current].name}
                </div>
                <div className="text-gray-400 text-sm">
                  {testimonials[current].role}
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === current ? "w-6 bg-cyan-400" : "w-1.5 bg-white/20"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// ─── CTA Section ────────────────────────────────────────────────────────────────
const CTASection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="py-20 relative">
      {/* Background Image */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          backgroundImage: `url(${cta})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* BLACK OVERLAY - Applied for ALL screen sizes */}
      <div className="absolute inset-0 bg-black/70" />

      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Elevate Your Digital Presence?
          </h2>
          <p className="text-gray-300 mb-6">
            Join 500+ satisfied clients who trust us.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/contact"
              className="px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/30"
              style={{
                background: "linear-gradient(135deg, #0AB3C7, #006C92)",
              }}
            >
              Get Free Consultation
            </Link>
            <Link
              to="/portfolio"
              className="px-6 py-3 rounded-md font-semibold text-cyan-400 text-sm transition-all hover:text-white hover:bg-cyan-500/20"
              style={{ border: "1px solid rgba(10,179,199,0.4)" }}
            >
              View Portfolio
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// ─── Main Home Export ───────────────────────────────────────────────────────────
const Home = () => {
  useEffect(() => {
    document.body.classList.add("bg-black");
    return () => document.body.classList.remove("bg-black");
  }, []);

  // Then in the return statement, use them:
  return (
    <div className="bg-black overflow-x-hidden">
      <HeroSection />
      <TrustedSection />
      <AboutSection />
      <ServicesSection />
      <GrowthSection />
      <WhyChooseUsSection />
      <PortfolioPreviewSection />
      <SocialMediaPackages /> {/* Reusable component */}
      <WebsitePackages /> {/* Reusable component */}
      <CTASection />
      <TestimonialsSection />
    </div>
  );
};

export default Home;
