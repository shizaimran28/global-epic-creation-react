// src/pages/Portfolio.jsx - Premium Dark Theme (Consistent with Homepage)
import React, { useState, useRef, useEffect } from "react";
import {
  motion,
  useInView,
  useScroll,
  useTransform,
  AnimatePresence,
} from "framer-motion";
import { Link } from "react-router-dom";
import heroDesktop from "../assets/hero.jpg";
import heroMobile from "../assets/hero2.jpg";
import cta from "../assets/CTA.jpg";
import {
  X,
  ArrowRight,
  ExternalLink,
  Calendar,
  User,
  Tag,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Eye,
  ZoomIn,
} from "lucide-react";

const Portfolio = () => {
  const [selectedProject, setSelectedProject] = useState(null);
  const [activeFilter, setActiveFilter] = useState("all");

  useEffect(() => {
    document.body.classList.add("bg-black");
    return () => document.body.classList.remove("bg-black");
  }, []);

  const categories = [
    "all",
    "Web Development",
    "UI/UX Design",
    "Branding",
    "Digital Marketing",
  ];

  const projects = [
    {
      id: 1,
      title: "Luxury E-Commerce Platform",
      category: "Web Development",
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop",
      largeImage:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=800&fit=crop",
      description:
        "A high-end e-commerce platform for luxury fashion brand with seamless checkout and immersive product experiences.",
      details:
        "Full-stack development using React, Node.js, and Stripe integration. Achieved 40% increase in conversion rate.",
      client: "Luxe Fashion House",
      date: "2024",
      technologies: ["React", "Node.js", "MongoDB", "Stripe", "Tailwind CSS"],
      challenge:
        "The client needed a modern e-commerce solution that could handle high traffic volumes while providing a luxurious shopping experience.",
      solution:
        "We built a fully responsive platform with custom animations, one-click checkout, and integrated payment gateways.",
      result:
        "40% increase in conversion rate, 60% faster page load times, and 200% increase in mobile sales.",
    },
    {
      id: 2,
      title: "FinTech Mobile App",
      category: "UI/UX Design",
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
      largeImage:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=800&fit=crop",
      description:
        "User-centered mobile banking app with intuitive navigation and secure authentication.",
      details:
        "Designed and prototyped a complete mobile banking experience with focus on accessibility and ease of use.",
      client: "NexGen Bank",
      date: "2024",
      technologies: [
        "Figma",
        "Adobe XD",
        "User Testing",
        "Prototyping",
        "iOS",
        "Android",
      ],
      challenge:
        "Creating a banking app that balances security with user-friendly design.",
      solution:
        "Implemented biometric authentication, intuitive navigation, and personalized dashboards.",
      result:
        "95% user satisfaction rate, 50% reduction in support tickets, 4.8/5 app store rating.",
    },
    {
      id: 3,
      title: "Brand Identity Suite",
      category: "Branding",
      image:
        "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&h=600&fit=crop",
      largeImage:
        "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=1200&h=800&fit=crop",
      description:
        "Complete brand overhaul including logo design, color palette, and brand guidelines.",
      details:
        "Developed a modern brand identity that resonates with younger demographic while maintaining brand heritage.",
      client: "Heritage Co.",
      date: "2023",
      technologies: [
        "Brand Strategy",
        "Logo Design",
        "Typography",
        "Guidelines",
        "Packaging",
      ],
      challenge:
        "Modernizing a 50-year-old brand without alienating existing customers.",
      solution:
        "Created a flexible brand system with modern elements while preserving core brand values.",
      result:
        "35% increase in brand awareness, 25% growth in new customers, successful market expansion.",
    },
    {
      id: 4,
      title: "SaaS Dashboard",
      category: "Web Development",
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
      largeImage:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=800&fit=crop",
      description:
        "Analytics dashboard for business intelligence with real-time data visualization.",
      details:
        "Built scalable dashboard with custom charts, export functionality, and role-based access control.",
      client: "DataVision Inc.",
      date: "2024",
      technologies: ["React", "D3.js", "Firebase", "Tailwind", "Chart.js"],
      challenge: "Processing and visualizing large datasets in real-time.",
      solution:
        "Implemented efficient data fetching, caching strategies, and optimized rendering.",
      result:
        "70% faster data processing, improved decision-making, 100+ active enterprise users.",
    },
    {
      id: 5,
      title: "Social Media Campaign",
      category: "Digital Marketing",
      image:
        "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800&h=600&fit=crop",
      largeImage:
        "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=1200&h=800&fit=crop",
      description:
        "Integrated social media campaign that increased engagement by 200%.",
      details:
        "Multi-platform campaign with influencer partnerships, user-generated content, and targeted advertising.",
      client: "Urban Lifestyle",
      date: "2024",
      technologies: [
        "Instagram",
        "TikTok",
        "Analytics",
        "Content Strategy",
        "Influencer Marketing",
      ],
      challenge: "Breaking through saturated social media channels.",
      solution:
        "Developed unique content strategy and partnered with micro-influencers for authentic engagement.",
      result:
        "200% engagement increase, 150% follower growth, 80% increase in website traffic.",
    },
    {
      id: 6,
      title: "Healthcare Portal",
      category: "UI/UX Design",
      image:
        "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop",
      largeImage:
        "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200&h=800&fit=crop",
      description:
        "Patient portal with appointment scheduling and telemedicine features.",
      details:
        "User research-driven design focused on accessibility and ease of navigation for all age groups.",
      client: "MediCare Plus",
      date: "2023",
      technologies: [
        "User Research",
        "Wireframing",
        "Usability Testing",
        "Accessibility",
        "Telemedicine",
      ],
      challenge:
        "Designing for diverse user groups including elderly patients.",
      solution:
        "Conducted extensive user testing and implemented accessibility features.",
      result:
        "60% increase in appointment bookings, 90% patient satisfaction, 40% reduction in no-shows.",
    },
  ];

  const filteredProjects =
    activeFilter === "all"
      ? projects
      : projects.filter((p) => p.category === activeFilter);

  return (
    <div className="bg-black overflow-x-hidden">
      <HeroSection />

      {/* Filter Section */}
      <section className="py-8 sticky top-20 z-20 bg-black/80 backdrop-blur-sm">
        <div className="container-custom">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-2.5 rounded-md text-sm font-medium transition-all duration-300 ${
                  activeFilter === category
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30"
                    : "bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white border border-white/10"
                }`}
              >
                {category === "all" ? "All Work" : category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-12">
        <div className="container-custom">
          <motion.div
            layout
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="wait">
              {filteredProjects.map((project, index) => (
                <PortfolioItem
                  key={project.id}
                  project={project}
                  index={index}
                  onOpen={() => setSelectedProject(project)}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <CTASection />

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <ProjectModal
            project={selectedProject}
            onClose={() => setSelectedProject(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

// Hero Section
const HeroSection = () => {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 60]);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[70vh] flex items-center justify-center overflow-hidden"
    >
      {/* Desktop Background */}
      <div
        className="absolute inset-0 z-0 w-full h-full hidden sm:block"
        style={{
          backgroundImage: `url(${heroDesktop})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* Mobile Background */}
      <div
        className="absolute inset-0 z-0 w-full h-full block sm:hidden"
        style={{
          backgroundImage: `url(${heroMobile})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* BLACK OVERLAY - Applied to BOTH desktop and mobile */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90 z-0" />
      <motion.div
        className="container-custom relative z-10 text-center"
        style={{ y }}
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 pt-20 leading-[1.2] tracking-tight">
            Our{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Portfolio
            </span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            A showcase of our finest work across industries and disciplines.
          </p>
        </motion.div>
      </motion.div>
    </section>
  );
};

// Portfolio Item Component
const PortfolioItem = ({ project, index, onOpen }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <motion.div
      ref={ref}
      layout
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className="group cursor-pointer"
      onClick={onOpen}
    >
      <div className="relative overflow-hidden rounded-2xl">
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-6">
          <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
            <p className="text-cyan-400 text-sm mb-1 font-semibold">
              {project.category}
            </p>
            <h3 className="text-white text-xl font-bold mb-2">
              {project.title}
            </h3>
            <div className="flex items-center text-cyan-400 text-sm">
              <span>View Case Study</span>
              <ArrowRight
                size={14}
                className="ml-2 group-hover:translate-x-1 transition-transform"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="mt-4">
        <p className="text-cyan-400 text-sm font-semibold">
          {project.category}
        </p>
        <h3 className="text-lg font-bold text-white">{project.title}</h3>
      </div>
    </motion.div>
  );
};

// Project Modal
const ProjectModal = ({ project, onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 20 }}
        transition={{ duration: 0.3 }}
        className="relative max-w-5xl w-full bg-black/90 rounded-2xl overflow-hidden max-h-[90vh] overflow-y-auto border border-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-cyan-500/20 transition-all duration-300 border border-white/10"
        >
          <X size={20} className="text-white" />
        </button>

        <img
          src={project.largeImage || project.image}
          alt={project.title}
          className="w-full h-80 object-cover"
        />

        <div className="p-8">
          <div className="mb-8">
            <span className="inline-flex items-center px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-sm font-semibold">
              {project.category}
            </span>
            <h2 className="text-3xl font-bold text-white mt-4 mb-4">
              {project.title}
            </h2>
            <p className="text-gray-400 text-lg">{project.description}</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8 p-6 rounded-2xl bg-white/5 border border-white/10">
            <div>
              <div className="flex items-center gap-2 text-cyan-400 mb-2">
                <User size={16} />
                <span className="text-sm font-semibold">Client</span>
              </div>
              <p className="text-gray-300">{project.client}</p>
            </div>
            <div>
              <div className="flex items-center gap-2 text-cyan-400 mb-2">
                <Calendar size={16} />
                <span className="text-sm font-semibold">Year</span>
              </div>
              <p className="text-gray-300">{project.date}</p>
            </div>
            <div>
              <div className="flex items-center gap-2 text-cyan-400 mb-2">
                <Tag size={16} />
                <span className="text-sm font-semibold">Category</span>
              </div>
              <p className="text-gray-300">{project.category}</p>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-bold text-white mb-4">
              Technologies Used
            </h3>
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 bg-white/5 border border-white/10 text-gray-300 text-sm rounded-md"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="p-4 rounded-xl bg-white/5 border border-white/10">
              <h4 className="text-cyan-400 font-semibold mb-2">Challenge</h4>
              <p className="text-gray-400 text-sm">{project.challenge}</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10">
              <h4 className="text-cyan-400 font-semibold mb-2">Solution</h4>
              <p className="text-gray-400 text-sm">{project.solution}</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10">
              <h4 className="text-cyan-400 font-semibold mb-2">Result</h4>
              <p className="text-gray-400 text-sm">{project.result}</p>
            </div>
          </div>

          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 bg-gradient-to-r from-cyan-500 to-blue-600 hover:shadow-lg hover:shadow-cyan-500/30"
          >
            Discuss Your Project <ArrowRight size={14} />
          </Link>
        </div>
      </motion.div>
    </motion.div>
  );
};

// CTA Section
const CTASection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="py-24 relative">
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          backgroundImage: `url(${cta})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* BLACK OVERLAY - Fixed for mobile */}
      <div className="absolute inset-0 bg-black/70" />

      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Ready to Create Your
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {" "}
              Success Story?
            </span>
          </h2>
          <p className="text-gray-300 mb-8">
            Let's collaborate to bring your vision to life.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/30"
            style={{
              background: "linear-gradient(135deg, #0AB3C7, #006C92)",
            }}
          >
            Start Your Project <ArrowRight size={14} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
