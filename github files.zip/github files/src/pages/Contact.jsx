// src/pages/Contact.jsx - Premium Dark Theme (Consistent with Homepage)
import React, { useRef, useState, useEffect } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { Link } from "react-router-dom";
import heroDesktop from "../assets/hero.jpg";
import heroMobile from "../assets/hero2.jpg";
import cta from "../assets/CTA.jpg";
import {
  Mail,
  Phone,
  MapPin,
  Instagram,
  Twitter,
  Linkedin,
  Send,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Clock,
  CheckCircle,
  MessageCircle,
  Globe,
} from "lucide-react";

const Contact = () => {
  useEffect(() => {
    document.body.classList.add("bg-black");
    return () => document.body.classList.remove("bg-black");
  }, []);

  return (
    <div className="bg-black overflow-x-hidden">
      <HeroSection />
      <ContactSection />
      <MapSection />
      <FAQSection />
      <CTASection />
    </div>
  );
};

// Hero Section
const HeroSection = () => {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 60]);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[70vh] flex items-center justify-center overflow-hidden"
    >
      {/* Desktop Background */}
      <div
        className="absolute inset-0 z-0 w-full h-full hidden sm:block"
        style={{
          backgroundImage: `url(${heroDesktop})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* Mobile Background */}
      <div
        className="absolute inset-0 z-0 w-full h-full block sm:hidden"
        style={{
          backgroundImage: `url(${heroMobile})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* BLACK OVERLAY - Applied to BOTH desktop and mobile */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90 z-0" />
      <motion.div
        className="container-custom relative z-10 text-center"
        style={{ y }}
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 pt-20 leading-[1.2] tracking-tight">
            Let's Start a
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent block">
              Conversation
            </span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Ready to transform your digital presence? We're here to help.
          </p>
        </motion.div>
      </motion.div>
    </section>
  );
};

// Contact Section
const ContactSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [focused, setFocused] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setFormData({ name: "", email: "", phone: "", message: "" });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFocus = (field) => {
    setFocused({ ...focused, [field]: true });
  };

  const handleBlur = (field, value) => {
    if (!value) {
      setFocused({ ...focused, [field]: false });
    }
  };

  const contactInfo = [
    {
      icon: Mail,
      title: "Email Us",
      value: "hello@epiccreation.com",
      link: "mailto:hello@epiccreation.com",
      description: "We'll respond within 24 hours",
    },
    {
      icon: Phone,
      title: "Call Us",
      value: "+1 (555) 123-4567",
      link: "tel:+15551234567",
      description: "Mon-Fri, 9AM - 6PM EST",
    },
    {
      icon: MapPin,
      title: "Visit Us",
      value: "123 Creative Avenue, New York, NY 10001",
      link: "https://maps.google.com",
      description: "By appointment only",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black/40">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="text-cyan-400 text-sm font-semibold uppercase tracking-wider mb-4 block">
              Contact Information
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Get in
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                {" "}
                Touch With Us
              </span>
            </h2>
            <p className="text-gray-400 mb-8">
              Have a project in mind or just want to say hello? We'd love to
              hear from you.
            </p>

            <div className="space-y-4 mb-8">
              {contactInfo.map((item, index) => (
                <a
                  key={index}
                  href={item.link}
                  target={item.icon === MapPin ? "_blank" : undefined}
                  rel={item.icon === MapPin ? "noopener noreferrer" : undefined}
                  className="flex items-start gap-4 group p-4 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-500/30 transition-all duration-300"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <item.icon size={22} className="text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">
                      {item.title}
                    </h3>
                    <p className="text-cyan-400 text-sm mb-1">{item.value}</p>
                    <p className="text-gray-500 text-xs">{item.description}</p>
                  </div>
                </a>
              ))}
            </div>

            <div>
              <h3 className="font-semibold text-white mb-4">Follow Us</h3>
              <div className="flex gap-3">
                <a
                  href="#"
                  className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-cyan-500/20 hover:border-cyan-500/30 transition-all group"
                >
                  <Instagram
                    size={18}
                    className="text-gray-400 group-hover:text-cyan-400"
                  />
                </a>
                <a
                  href="#"
                  className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-cyan-500/20 hover:border-cyan-500/30 transition-all group"
                >
                  <Twitter
                    size={18}
                    className="text-gray-400 group-hover:text-cyan-400"
                  />
                </a>
                <a
                  href="#"
                  className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-cyan-500/20 hover:border-cyan-500/30 transition-all group"
                >
                  <Linkedin
                    size={18}
                    className="text-gray-400 group-hover:text-cyan-400"
                  />
                </a>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="p-8 rounded-2xl bg-white/5 border border-white/10"
          >
            <h2 className="text-2xl font-bold text-white mb-6">
              Send Us a Message
            </h2>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  onFocus={() => handleFocus("name")}
                  onBlur={(e) => handleBlur("name", e.target.value)}
                  required
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border transition-all duration-300 outline-none text-white placeholder-gray-500 ${
                    focused.name
                      ? "border-cyan-500/50 ring-2 ring-cyan-500/20"
                      : "border-white/10 focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20"
                  }`}
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  onFocus={() => handleFocus("email")}
                  onBlur={(e) => handleBlur("email", e.target.value)}
                  required
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border transition-all duration-300 outline-none text-white placeholder-gray-500 ${
                    focused.email
                      ? "border-cyan-500/50 ring-2 ring-cyan-500/20"
                      : "border-white/10 focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20"
                  }`}
                  placeholder="hello@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  onFocus={() => handleFocus("phone")}
                  onBlur={(e) => handleBlur("phone", e.target.value)}
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border transition-all duration-300 outline-none text-white placeholder-gray-500 ${
                    focused.phone
                      ? "border-cyan-500/50 ring-2 ring-cyan-500/20"
                      : "border-white/10 focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20"
                  }`}
                  placeholder="+1 (555) 000-0000"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  onFocus={() => handleFocus("message")}
                  onBlur={(e) => handleBlur("message", e.target.value)}
                  required
                  rows="4"
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border transition-all duration-300 outline-none text-white placeholder-gray-500 resize-none ${
                    focused.message
                      ? "border-cyan-500/50 ring-2 ring-cyan-500/20"
                      : "border-white/10 focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20"
                  }`}
                  placeholder="Tell us about your project..."
                />
              </div>
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/30 bg-gradient-to-r from-cyan-500 to-blue-600"
              >
                {submitted ? (
                  <>
                    <CheckCircle size={16} /> Message Sent!
                  </>
                ) : (
                  <>
                    Send Message <Send size={14} />
                  </>
                )}
              </button>
              {submitted && (
                <p className="text-cyan-400 text-sm text-center mt-3">
                  Thank you! We'll get back to you soon.
                </p>
              )}
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Map Section
const MapSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section ref={ref} className="py-12">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="rounded-2xl overflow-hidden h-96 relative"
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none z-10" />
          <iframe
            title="Office Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a316bb5d5f5%3A0xc89d98a9a3e3e9a3!2sNew%20York%2C%20NY!5e0!3m2!1sen!2sus!4v1644261234567!5m2!1sen!2sus"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            className="grayscale hover:grayscale-0 transition-all duration-700"
          />
        </motion.div>
      </div>
    </section>
  );
};

// FAQ Section
const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const faqs = [
    {
      q: "What is your typical project timeline?",
      a: "Project timelines vary based on scope and complexity. A typical website project takes 4-8 weeks, while smaller projects may take 2-3 weeks. We'll provide a detailed timeline during our initial consultation.",
    },
    {
      q: "How much do your services cost?",
      a: "Our pricing is customized based on each project's unique requirements. We offer competitive rates and flexible payment structures. Contact us for a free, no-obligation quote.",
    },
    {
      q: "Do you provide ongoing support?",
      a: "Yes, we offer maintenance and support packages to ensure your digital presence remains optimal. This includes updates, security monitoring, and technical support.",
    },
    {
      q: "How do you ensure project success?",
      a: "We follow a structured process including discovery, strategy, regular check-ins, and quality assurance. Client satisfaction is our top priority throughout the project lifecycle.",
    },
    {
      q: "Can you work with our existing team?",
      a: "Absolutely! We collaborate seamlessly with in-house teams, providing additional expertise and resources as needed to achieve your goals.",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black/40">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-cyan-400 text-sm font-semibold uppercase tracking-wider mb-4 block">
            FAQ
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Frequently Asked
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {" "}
              Questions
            </span>
          </h2>
          <p className="text-gray-400">
            Find answers to common questions about our services and process.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="mb-4"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-500/30 transition-all duration-300"
              >
                <span className="font-semibold text-white text-left">
                  {faq.q}
                </span>
                {openIndex === index ? (
                  <ChevronUp
                    size={20}
                    className="text-cyan-400 flex-shrink-0"
                  />
                ) : (
                  <ChevronDown
                    size={20}
                    className="text-cyan-400 flex-shrink-0"
                  />
                )}
              </button>
              {openIndex === index && (
                <div className="px-6 py-4 rounded-b-xl bg-white/5 border-x border-b border-white/10">
                  <p className="text-gray-400">{faq.a}</p>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// CTA Section
const CTASection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="py-24 relative">
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          backgroundImage: `url(${cta})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* BLACK OVERLAY - Fixed for mobile */}
      <div className="absolute inset-0 bg-black/70" />

      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Ready to Start Your
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              {" "}
              Project?
            </span>
          </h2>
          <p className="text-gray-300 mb-8">
            Get a free consultation and estimate for your project.
          </p>
          <button
            onClick={() =>
              document
                .querySelector("form")
                ?.scrollIntoView({ behavior: "smooth" })
            }
            className="inline-flex items-center gap-2 px-6 py-3 rounded-md font-semibold text-white text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/30"
            style={{
              background: "linear-gradient(135deg, #0AB3C7, #006C92)",
            }}
          >
            Get Free Quote <MessageCircle size={14} />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;
