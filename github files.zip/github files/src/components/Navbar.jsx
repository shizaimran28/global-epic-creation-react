// src/components/Navbar.jsx - Premium Dark Theme Navbar
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import logo from "../assets/logo.png";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  // Phone number - format with country code (without spaces or special characters)
  const PHONE_NUMBER = "+2080819450"; // Replace with your actual phone number
  const CALL_URL = `tel:${PHONE_NUMBER}`;

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
    document.body.style.overflow = "";
  }, [location]);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Portfolio", path: "/portfolio" },
    { name: "Services", path: "/services" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  const isHome = location.pathname === "/";
  const isTransparent = isHome && !scrolled;

  const navBg = scrolled
    ? "rgba(0,0,0,0.95)"
    : isHome
      ? "rgba(0,0,0,0.5)"
      : "rgba(0,0,0,0.95)";

  const navBlur = scrolled ? "blur(16px)" : "blur(8px)";
  const navBorder = scrolled
    ? "1px solid rgba(10,179,199,0.15)"
    : "1px solid rgba(255,255,255,0.05)";

  return (
    <>
      <nav
        className="fixed w-full z-50 transition-all duration-500"
        style={{
          background: navBg,
          backdropFilter: navBlur,
          WebkitBackdropFilter: navBlur,
          borderBottom: navBorder,
          padding: scrolled ? "12px 0" : "20px 0",
        }}
      >
        <div className="container-custom">
          <div className="flex items-center justify-between">
            {/* Logo - Image only (if PNG has text) */}
            <Link to="/" className="flex items-center group">
              <div className="relative">
                <img
                  src={logo}
                  alt="EPIC CREATION Logo"
                  className="relative h-12 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
                />
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className="relative px-4 py-2 rounded-lg text-sm font-medium transition-all duration-250 group"
                    style={{
                      color: isActive ? "#0AB3C7" : "rgba(255,255,255,0.65)",
                    }}
                  >
                    <span
                      className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                      style={{ background: "rgba(10,179,199,0.08)" }}
                    />
                    <span className="relative z-10">{link.name}</span>
                    {isActive && (
                      <span
                        className="absolute bottom-0 left-4 right-4 h-0.5 rounded-full"
                        style={{
                          background:
                            "linear-gradient(to right, #006C92, #0AB3C7)",
                        }}
                      />
                    )}
                  </Link>
                );
              })}
            </div>

            {/* Desktop CTA - Call Us Button */}
            <div className="hidden md:flex items-center gap-3">
              <a
                href={CALL_URL}
                className="group relative inline-flex items-center gap-2 px-5 py-2.5 rounded-md text-sm font-bold text-white overflow-hidden transition-all duration-300 hover:scale-105"
              >
                <span className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-600" />
                <span className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <Phone size={16} className="relative z-10" />
                <span className="relative z-10">Call Us Now</span>
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200"
              style={{
                background: "rgba(255,255,255,0.08)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
              aria-label="Toggle menu"
            >
              {isOpen ? (
                <X size={20} className="text-white" />
              ) : (
                <Menu size={20} className="text-white" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40"
            style={{
              background: "rgba(0,0,0,0.98)",
              backdropFilter: "blur(20px)",
            }}
          >
            <div className="pt-24 px-8 flex flex-col h-full">
              <nav className="flex flex-col gap-2 flex-1">
                {navLinks.map((link, i) => {
                  const isActive = location.pathname === link.path;
                  return (
                    <motion.div
                      key={link.path}
                      initial={{ opacity: 0, x: -24 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * i, duration: 0.3 }}
                    >
                      <Link
                        to={link.path}
                        className="flex items-center justify-between py-4 border-b transition-colors duration-200 group"
                        style={{
                          borderColor: "rgba(255,255,255,0.06)",
                          color: isActive
                            ? "#0AB3C7"
                            : "rgba(255,255,255,0.65)",
                        }}
                      >
                        <span
                          className="text-xl font-bold group-hover:text-white transition-colors"
                          style={{ fontFamily: "'Sora', sans-serif" }}
                        >
                          {link.name}
                        </span>
                        <span className="text-xs font-semibold uppercase tracking-widest opacity-40 group-hover:opacity-80 transition-opacity">
                          0{i + 1}
                        </span>
                      </Link>
                    </motion.div>
                  );
                })}
              </nav>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="pb-12 pt-8"
              >
                {/* Mobile CTA - Call Us Button */}
                <a
                  href={CALL_URL}
                  className="block text-center font-bold py-4 rounded-md transition-all duration-300 flex items-center justify-center gap-2"
                  style={{
                    background: "linear-gradient(135deg, #006C92, #0AB3C7)",
                    color: "#ffffff",
                    fontSize: "1rem",
                  }}
                >
                  <Phone size={18} />
                  Call Us Now
                </a>

                <div className="flex justify-center gap-6 mt-8">
                  {["Instagram", "LinkedIn", "Twitter"].map((s) => (
                    <a
                      key={s}
                      href="#"
                      className="text-xs font-semibold uppercase tracking-widest text-gray-500 hover:text-cyan-400 transition-colors"
                    >
                      {s}
                    </a>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;
