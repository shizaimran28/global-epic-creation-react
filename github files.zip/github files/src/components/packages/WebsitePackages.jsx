// src/components/packages/WebsitePackages.jsx
import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Globe,
  Users,
  FileCode,
  Layout,
  Lock,
  MousePointer,
  RefreshCw,
  Database,
  Package as PackageIcon,
  CreditCard,
  Store,
  FileText,
  ShoppingCart,
} from "lucide-react";

const WebsitePackages = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const packages = [
    {
      id: "static",
      name: "Static Website",
      price: "£250",
      priceSuffix: "One-Time Payment",
      recommended: false,
      icon: FileCode,
      features: [
        { name: "4–5 pages", icon: FileText, highlight: false },
        { name: "Simple fixed website", icon: Layout, highlight: false },
        { name: "Unchanging content", icon: Lock, highlight: false },
        {
          name: "No complex interactions",
          icon: MousePointer,
          highlight: false,
        },
        { name: "Changes included", icon: RefreshCw, highlight: false },
      ],
      ctaText: "Request Quote",
      ctaLink: "/contact",
    },
    {
      id: "dynamic",
      name: "Dynamic Website",
      price: "£550",
      priceSuffix: "One-Time Payment",
      recommended: true,
      icon: Globe,
      features: [
        { name: "5–7 pages", icon: FileText, highlight: true },
        {
          name: "Interactive functionality",
          icon: MousePointer,
          highlight: true,
        },
        { name: "Dynamic content", icon: RefreshCw, highlight: true },
        { name: "User interaction support", icon: Users, highlight: true },
        {
          name: "Backend integration capability",
          icon: Database,
          highlight: true,
        },
      ],
      ctaText: "Request Quote",
      ctaLink: "/contact",
    },
    {
      id: "ecommerce",
      name: "E-commerce Website",
      price: "£750",
      priceSuffix: "One-Time Payment",
      recommended: false,
      icon: ShoppingCart,
      features: [
        { name: "Up to 10 pages", icon: FileText, highlight: false },
        { name: "Product management", icon: PackageIcon, highlight: false },
        {
          name: "Shopping cart functionality",
          icon: ShoppingCart,
          highlight: false,
        },
        { name: "Payment integration", icon: CreditCard, highlight: false },
        { name: "Online store setup", icon: Store, highlight: false },
      ],
      ctaText: "Request Quote",
      ctaLink: "/contact",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black">
      <div className="container-custom mx-auto px-4 md:px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <span className="text-xs font-mono text-cyan-400 mb-2 block tracking-wider">
            WEB SOLUTIONS
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Website{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Development Packages
            </span>
          </h2>
          <p className="text-gray-400 text-base max-w-2xl mx-auto">
            Professional web solutions tailored to your business needs
          </p>
        </motion.div>

        {/* Packages Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className={`relative rounded-2xl transition-all duration-300 ${
                pkg.recommended
                  ? "bg-gradient-to-b from-cyan-500/10 via-blue-500/5 to-black border border-cyan-500/30 shadow-xl shadow-cyan-500/10"
                  : "bg-white/5 border border-white/10 hover:border-white/20"
              }`}
            >
              {/* Recommended Badge */}
              {pkg.recommended && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-4 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-cyan-400 to-blue-500 text-white shadow-lg">
                    BEST VALUE
                  </span>
                </div>
              )}

              {/* Card Content */}
              <div className="p-6 lg:p-8">
                {/* Icon & Package Name */}
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      pkg.recommended
                        ? "bg-gradient-to-br from-cyan-500/20 to-blue-500/20"
                        : "bg-white/10"
                    }`}
                  >
                    <pkg.icon
                      size={20}
                      className={
                        pkg.recommended ? "text-cyan-400" : "text-gray-400"
                      }
                    />
                  </div>
                  <h3 className="text-xl font-bold text-white">{pkg.name}</h3>
                </div>

                {/* Price */}
                <div className="mb-6">
                  <span className="text-4xl lg:text-5xl font-bold text-white">
                    {pkg.price}
                  </span>
                  <span className="text-gray-400 text-xs ml-1 block">
                    {pkg.priceSuffix}
                  </span>
                </div>

                {/* Features List */}
                <div className="space-y-2.5 mb-8">
                  {pkg.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center ${
                          feature.highlight ? "bg-cyan-500/20" : "bg-white/10"
                        }`}
                      >
                        <feature.icon
                          size={12}
                          className={
                            feature.highlight
                              ? "text-cyan-400"
                              : "text-gray-500"
                          }
                        />
                      </div>
                      <span
                        className={`text-sm ${
                          feature.highlight ? "text-gray-300" : "text-gray-500"
                        }`}
                      >
                        {feature.name}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Link
                  to={pkg.ctaLink}
                  className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-semibold text-sm transition-all duration-300 group ${
                    pkg.recommended
                      ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-white shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-105"
                      : "border border-white/20 text-white hover:bg-white/10 hover:border-white/30"
                  }`}
                >
                  {pkg.ctaText}
                  <ArrowRight
                    size={14}
                    className="group-hover:translate-x-1 transition-transform duration-300"
                  />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-8"
        >
          <p className="text-gray-500 text-xs">
            * All packages include responsive design • SEO optimized • 30 days
            free support
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default WebsitePackages;
