// src/components/packages/SocialMediaPackages.jsx
import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Share2,
  PenTool,
  TrendingUp,
  Calendar,
  CalendarDays,
  BarChart3,
} from "lucide-react";

const SocialMediaPackages = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  const packages = [
    {
      id: "basic",
      name: "Basic Package",
      price: "£150",
      pricePeriod: "month",
      recommended: false,
      features: [
        { name: "8 posts per week", icon: Calendar, highlight: false },
        {
          name: "1 social media platform managed",
          icon: Share2,
          highlight: false,
        },
        { name: "Basic reporting", icon: BarChart3, highlight: false },
        { name: "Content planning included", icon: PenTool, highlight: false },
      ],
      ctaText: "Get Started",
      ctaLink: "/contact",
    },
    {
      id: "standard",
      name: "Standard Package",
      price: "£250",
      pricePeriod: "month",
      recommended: true,
      features: [
        { name: "10 posts per week", icon: Calendar, highlight: true },
        {
          name: "Up to 2 social media platforms managed",
          icon: Share2,
          highlight: true,
        },
        { name: "Advanced reporting", icon: BarChart3, highlight: true },
        {
          name: "Content calendar included",
          icon: CalendarDays,
          highlight: true,
        },
        { name: "Ad strategy included", icon: TrendingUp, highlight: true },
      ],
      ctaText: "Get Started",
      ctaLink: "/contact",
    },
    {
      id: "premium",
      name: "Premium Package",
      price: "£450",
      pricePeriod: "month",
      recommended: false,
      features: [
        { name: "20 posts per week", icon: Calendar, highlight: false },
        {
          name: "Up to 3 social media platforms managed",
          icon: Share2,
          highlight: false,
        },
        { name: "Advanced reporting", icon: BarChart3, highlight: false },
        {
          name: "Content calendar included",
          icon: CalendarDays,
          highlight: false,
        },
        { name: "Ad strategy included", icon: TrendingUp, highlight: false },
      ],
      ctaText: "Get Started",
      ctaLink: "/contact",
    },
  ];

  return (
    <section ref={ref} className="py-24 bg-black/40">
      <div className="container-custom mx-auto px-4 md:px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <span className="text-xs font-mono text-cyan-400 mb-2 block tracking-wider">
            PRICING PLANS
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Social Media{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Marketing Packages
            </span>
          </h2>
          <p className="text-gray-400 text-base max-w-2xl mx-auto">
            Choose the perfect plan to amplify your brand's social media
            presence
          </p>
        </motion.div>

        {/* Packages Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className={`relative rounded-2xl transition-all duration-300 ${
                pkg.recommended
                  ? "bg-gradient-to-b from-cyan-500/10 via-blue-500/5 to-black border border-cyan-500/30 shadow-xl shadow-cyan-500/10"
                  : "bg-white/5 border border-white/10 hover:border-white/20"
              }`}
            >
              {/* Recommended Badge */}
              {pkg.recommended && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-4 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-cyan-400 to-blue-500 text-white shadow-lg">
                    MOST POPULAR
                  </span>
                </div>
              )}

              {/* Card Content */}
              <div className="p-6 lg:p-8">
                {/* Package Name */}
                <h3 className="text-xl font-bold text-white mb-2">
                  {pkg.name}
                </h3>

                {/* Price */}
                <div className="mb-6">
                  <span className="text-4xl lg:text-5xl font-bold text-white">
                    {pkg.price}
                  </span>
                  <span className="text-gray-400 text-sm ml-1">
                    /{pkg.pricePeriod}
                  </span>
                </div>

                {/* Features List */}
                <div className="space-y-3 mb-8">
                  {pkg.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center ${
                          feature.highlight ? "bg-cyan-500/20" : "bg-white/10"
                        }`}
                      >
                        <feature.icon
                          size={12}
                          className={
                            feature.highlight
                              ? "text-cyan-400"
                              : "text-gray-500"
                          }
                        />
                      </div>
                      <span
                        className={`text-sm ${
                          feature.highlight ? "text-gray-300" : "text-gray-500"
                        }`}
                      >
                        {feature.name}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Link
                  to={pkg.ctaLink}
                  className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-semibold text-sm transition-all duration-300 group ${
                    pkg.recommended
                      ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-white shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-105"
                      : "border border-white/20 text-white hover:bg-white/10 hover:border-white/30"
                  }`}
                >
                  {pkg.ctaText}
                  <ArrowRight
                    size={14}
                    className="group-hover:translate-x-1 transition-transform duration-300"
                  />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Trust Note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center text-gray-500 text-xs mt-8"
        >
          No hidden fees • Cancel anytime • 14-day money-back guarantee
        </motion.p>
      </div>
    </section>
  );
};

export default SocialMediaPackages;
