// src/components/Footer.jsx - Premium Dark Theme Footer (Mobile Responsive)
import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Mail,
  Phone,
  MapPin,
  Instagram,
  Twitter,
  Linkedin,
  ArrowUp,
  ArrowRight,
  Send,
  Sparkles,
} from "lucide-react";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail("");
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  const quickLinks = [
    { label: "Home", path: "/" },
    { label: "About Us", path: "/about" },
    { label: "Portfolio", path: "/portfolio" },
    { label: "Contact", path: "/contact" },
  ];

  const serviceLinks = [
    { label: "Web Development", path: "/services" },
    { label: "UI/UX Design", path: "/services" },
    { label: "Digital Marketing", path: "/services" },
    { label: "Branding", path: "/services" },
    { label: "SEO Optimization", path: "/services" },
  ];

  const socials = [
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Twitter, href: "#", label: "Twitter" },
  ];

  return (
    <footer className="relative bg-black overflow-hidden">
      {/* Top gradient line */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{
          background:
            "linear-gradient(to right, transparent, rgba(10,179,199,0.4), rgba(0,108,146,0.4), transparent)",
        }}
      />

      <div className="container-custom relative z-10 px-4 md:px-6">
        {/* Newsletter Section - Fixed for Mobile */}
        <div
          className="py-8 md:py-10 px-4 md:px-8 rounded-2xl mt-8 md:mt-12 mb-10 md:mb-14 flex flex-col items-center justify-between gap-6"
          style={{
            background:
              "linear-gradient(135deg, rgba(10,179,199,0.08) 0%, rgba(0,108,146,0.04) 100%)",
            border: "1px solid rgba(10,179,199,0.15)",
          }}
        >
          <div className="text-center">
            <div className="flex items-center gap-2 justify-center mb-2">
              <Sparkles size={16} className="text-cyan-400" />
              <h3 className="text-white font-bold text-base md:text-lg">
                Stay Ahead of the Curve
              </h3>
            </div>
            <p className="text-gray-400 text-xs md:text-sm">
              Get insights, case studies, and digital strategy tips — weekly.
            </p>
          </div>

          {/* Fixed Subscribe Form - Now properly responsive */}
          <form
            onSubmit={handleSubscribe}
            className="flex flex-col sm:flex-row gap-3 w-full max-w-md"
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200 bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-cyan-500/50 focus:bg-white/10"
              required
            />
            <button
              type="submit"
              className="w-full sm:w-auto px-5 py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all duration-300 hover:scale-105 whitespace-nowrap"
              style={{
                background: "linear-gradient(135deg, #006C92, #0AB3C7)",
                color: "#ffffff",
              }}
            >
              {subscribed ? (
                "Subscribed!"
              ) : (
                <>
                  <Send size={14} /> Subscribe
                </>
              )}
            </button>
          </form>
        </div>

        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 pb-8 md:pb-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2.5 mb-5 group w-fit">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-transform group-hover:scale-105"
                style={{
                  background: "linear-gradient(135deg, #006C92, #0AB3C7)",
                }}
              >
                <svg width="20" height="16" viewBox="0 0 20 16" fill="none">
                  <path
                    d="M0 0H12L16 4L12 8H0V0Z"
                    fill="white"
                    fillOpacity="0.9"
                  />
                  <path
                    d="M0 8H10L14 12L10 16H0V8Z"
                    fill="white"
                    fillOpacity="0.6"
                  />
                  <path
                    d="M14 4L20 4L20 12L14 12L18 8L14 4Z"
                    fill="white"
                    fillOpacity="0.75"
                  />
                </svg>
              </div>
              <span
                className="font-black text-white text-base md:text-lg tracking-tight"
                style={{ fontFamily: "'Sora', sans-serif" }}
              >
                EPIC<span className="text-cyan-400">CREATION</span>
              </span>
            </Link>

            <p className="text-gray-500 text-xs md:text-sm leading-relaxed mb-6">
              A premium digital agency crafting exceptional web experiences,
              brand identities, and growth strategies for ambitious businesses
              worldwide.
            </p>

            <div className="flex gap-3">
              {socials.map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-8 h-8 md:w-9 md:h-9 rounded-lg flex items-center justify-center transition-all duration-200 hover:-translate-y-0.5"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    color: "rgba(255,255,255,0.45)",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = "rgba(10,179,199,0.15)";
                    e.currentTarget.style.borderColor = "rgba(10,179,199,0.35)";
                    e.currentTarget.style.color = "#0AB3C7";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = "rgba(255,255,255,0.05)";
                    e.currentTarget.style.borderColor =
                      "rgba(255,255,255,0.08)";
                    e.currentTarget.style.color = "rgba(255,255,255,0.45)";
                  }}
                >
                  <Icon size={14} className="md:text-[15px]" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-[0.2em] mb-5 md:mb-6">
              Quick Links
            </h4>
            <ul className="space-y-2.5 md:space-y-3">
              {quickLinks.map(({ label, path }) => (
                <li key={label}>
                  <Link
                    to={path}
                    className="text-gray-500 text-xs md:text-sm flex items-center gap-2 transition-all duration-200 hover:gap-3 group"
                    onMouseEnter={(e) => {
                      e.currentTarget.style.color = "#0AB3C7";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.color = "rgb(107, 114, 128)";
                    }}
                  >
                    <ArrowRight
                      size={12}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-[0.2em] mb-5 md:mb-6">
              Services
            </h4>
            <ul className="space-y-2.5 md:space-y-3">
              {serviceLinks.map(({ label, path }) => (
                <li key={label}>
                  <Link
                    to={path}
                    className="text-gray-500 text-xs md:text-sm flex items-center gap-2 transition-all duration-200 group"
                    onMouseEnter={(e) => {
                      e.currentTarget.style.color = "#0AB3C7";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.color = "rgb(107, 114, 128)";
                    }}
                  >
                    <ArrowRight
                      size={12}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-[0.2em] mb-5 md:mb-6">
              Contact Us
            </h4>
            <ul className="space-y-4 md:space-y-5">
              <li className="flex items-start gap-3">
                <div
                  className="w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{
                    background: "rgba(10,179,199,0.1)",
                    border: "1px solid rgba(10,179,199,0.15)",
                  }}
                >
                  <MapPin size={13} className="md:text-[14px] text-cyan-400" />
                </div>
                <span className="text-gray-400 text-xs md:text-sm leading-relaxed">
                  Cardiff, CF14 8LH
                </span>
              </li>
              <li className="flex items-center gap-3">
                <div
                  className="w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center"
                  style={{
                    background: "rgba(10,179,199,0.1)",
                    border: "1px solid rgba(10,179,199,0.15)",
                  }}
                >
                  <Mail size={13} className="md:text-[14px] text-cyan-400" />
                </div>
                <a
                  href="https://mail.google.com/mail/?view=cm&fs=1&to=globalepiccreation@gmail.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 text-xs md:text-sm hover:text-cyan-400 transition-colors break-all"
                >
                  globalepiccreation@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <div
                  className="w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center"
                  style={{
                    background: "rgba(10,179,199,0.1)",
                    border: "1px solid rgba(10,179,199,0.15)",
                  }}
                >
                  <Phone size={13} className="md:text-[14px] text-cyan-400" />
                </div>
                <a
                  href="tel:+2080819450"
                  className="text-gray-400 text-xs md:text-sm hover:text-cyan-400 transition-colors"
                >
                  +2080819450
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar - Responsive */}
        <div
          className="flex flex-col sm:flex-row items-center justify-between gap-4 py-5 md:py-6"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
        >
          <p className="text-gray-600 text-[11px] md:text-xs order-2 sm:order-1">
            &copy; {new Date().getFullYear()} EPIC CREATION. All rights
            reserved.
          </p>
          <div className="flex items-center gap-4 md:gap-6 order-1 sm:order-2">
            <Link
              to="/privacy"
              className="text-gray-600 text-[11px] md:text-xs hover:text-gray-400 transition-colors"
            >
              Privacy Policy
            </Link>
            <Link
              to="/terms"
              className="text-gray-600 text-[11px] md:text-xs hover:text-gray-400 transition-colors"
            >
              Terms of Service
            </Link>
            <button
              onClick={scrollToTop}
              className="w-8 h-8 md:w-9 md:h-9 rounded-xl flex items-center justify-center transition-all duration-300 hover:-translate-y-1"
              style={{
                background: "rgba(10,179,199,0.1)",
                border: "1px solid rgba(10,179,199,0.2)",
              }}
              aria-label="Back to top"
            >
              <ArrowUp size={14} className="md:text-[16px] text-cyan-400" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
