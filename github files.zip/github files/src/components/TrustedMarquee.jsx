// src/components/TrustedMarquee.jsx
import React, { useRef, useEffect, useState } from "react";
import { motion } from "framer-motion";

// Brand names - clean and minimal
const brands = [
  "AIRBNB",
  "SPOTIFY",
  "NOTION",
  "VERCEL",
  "STRIPE",
  "LINEAR",
  "FIGMA",
  "SHOPIFY",
  "DROPBOX",
  "AIRTABLE",
  "MICROSOFT",
  "GOOGLE",
  "NETFLIX",
  "DISNEY",
  "AMAZON",
];

const TrustedSection = () => {
  const rowRef = useRef(null);
  const [contentWidth, setContentWidth] = useState(0);

  // Triple the brands for seamless loop
  const duplicatedBrands = [...brands, ...brands, ...brands];

  // Measure content width
  useEffect(() => {
    if (!rowRef.current) return;
    const updateWidth = () => {
      const innerContent = rowRef.current.querySelector(".marquee-content");
      if (innerContent) {
        setContentWidth(innerContent.scrollWidth / 3);
      }
    };
    updateWidth();
    window.addEventListener("resize", updateWidth);
    return () => window.removeEventListener("resize", updateWidth);
  }, []);

  return (
    <section className="py-12 bg-black/20 border-y border-white/5 overflow-hidden">
      <div className="container-custom mx-auto px-4">
        {/* Small minimal heading */}
        <div className="text-center mb-6">
          <p className="text-white text-md uppercase tracking-[0.2em] font-bold">
            Trusted by industry leaders
          </p>
        </div>

        {/* Single line marquee */}
        <div
          ref={rowRef}
          className="relative w-full overflow-hidden"
          style={{
            maskImage:
              "linear-gradient(to right, transparent, black 5%, black 95%, transparent)",
            WebkitMaskImage:
              "linear-gradient(to right, transparent, black 5%, black 95%, transparent)",
          }}
        >
          <motion.div
            className="flex gap-12 md:gap-16 w-max marquee-content"
            animate={{ x: [0, -contentWidth] }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear",
              repeatType: "loop",
            }}
            style={{ willChange: "transform" }}
          >
            {duplicatedBrands.map((brand, idx) => (
              <span
                key={`${brand}-${idx}`}
                className="text-gray-400 text-sm md:text-base font-medium tracking-wide whitespace-nowrap hover:text-gray-300 transition-colors duration-300"
              >
                {brand}
              </span>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TrustedSection;
