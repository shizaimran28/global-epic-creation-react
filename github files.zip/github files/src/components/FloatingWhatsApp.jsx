// src/components/FloatingWhatsApp.jsx
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import whatsappIcon from "../assets/whatsapp-logo.png"; // Make sure this path is correct

const FloatingWhatsApp = () => {
  const [showTooltip, setShowTooltip] = useState(false);

  // WhatsApp number - Replace with your actual number
  const WHATSAPP_NUMBER = "+447378602085";
  const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}`;

  const jumpAnimation = {
    animate: {
      y: [0, -12, 0],
      transition: {
        duration: 0.6,
        repeat: Infinity,
        repeatType: "reverse",
        ease: "easeOut",
      },
    },
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="fixed bottom-6 right-6 z-50"
    >
      {/* Tooltip */}
      <AnimatePresence>
        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-full right-0 mb-3 mr-2"
          >
            <div className="relative">
              <div className="bg-gray-900 text-white text-xs font-medium px-3 py-1.5 rounded-lg whitespace-nowrap shadow-lg border border-white/10">
                Chat with us on WhatsApp
                <div className="absolute -bottom-1 right-4 w-2 h-2 bg-gray-900 rotate-45 border-r border-b border-white/10"></div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* WhatsApp Button with PNG Icon */}
      <motion.a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        variants={jumpAnimation}
        animate="animate"
        className="flex items-center justify-center w-16 h-16 md:w-20 md:h-20 rounded-full shadow-2xl group relative overflow-hidden cursor-pointer"
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(8px)",
          border: "1px solid rgba(255, 255, 255, 0.15)",
          boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
        }}
      >
        <span className="absolute inset-0 w-full h-full rounded-full bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300" />

        {/* WhatsApp PNG Icon */}
        <img
          src={whatsappIcon}
          alt="WhatsApp"
          className="relative z-10 w-14 h-14 md:w-16 md:h-16 object-contain"
        />
      </motion.a>
    </motion.div>
  );
};

export default FloatingWhatsApp;
