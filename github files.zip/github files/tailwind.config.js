// tailwind.config.js
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          primary: "#006C92", // Deep Ocean Blue
          secondary: "#0AB3C7", // Bright Teal Cyan
          navy: "#0B132B", // Rich Navy
          gray: "#5F6B73", // Soft Gray
          white: "#FFFFFF",
        },
        accent: {
          glow: "#19D3E6",
          hover: "#11A8C0",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Cal Sans", "Inter", "system-ui", "sans-serif"],
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        "glow-pulse": "glowPulse 3s ease-in-out infinite",
        "slide-up": "slideUp 0.6s cubic-bezier(0.2, 0.8, 0.2, 1)",
        "fade-in": "fadeIn 0.8s ease-out",
        "scale-in": "scaleIn 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-20px)" },
        },
        glowPulse: {
          "0%, 100%": { opacity: 0.4, filter: "blur(8px)" },
          "50%": { opacity: 0.8, filter: "blur(4px)" },
        },
        slideUp: {
          "0%": { opacity: 0, transform: "translateY(30px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        },
        fadeIn: {
          "0%": { opacity: 0 },
          "100%": { opacity: 1 },
        },
        scaleIn: {
          "0%": { opacity: 0, transform: "scale(0.95)" },
          "100%": { opacity: 1, transform: "scale(1)" },
        },
      },
      boxShadow: {
        "premium-sm": "0 2px 4px rgba(0,0,0,0.02), 0 1px 2px rgba(0,0,0,0.03)",
        "premium-md":
          "0 10px 25px -5px rgba(0,0,0,0.03), 0 8px 10px -6px rgba(0,0,0,0.02)",
        "premium-lg": "0 20px 40px -12px rgba(0,0,0,0.08)",
        "premium-xl": "0 25px 50px -12px rgba(0,0,0,0.15)",
        "glow-cyan": "0 0 20px rgba(10, 179, 199, 0.15)",
        "glow-blue": "0 0 20px rgba(0, 108, 146, 0.1)",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "hero-glow":
          "radial-gradient(ellipse at 80% 30%, rgba(10,179,199,0.08), rgba(0,108,146,0.02), transparent)",
        "section-tint": "linear-gradient(135deg, #F8FAFC 0%, #FFFFFF 100%)",
      },
    },
  },
  plugins: [],
};
